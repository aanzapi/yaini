const RESTART_INTERVAL = 30 * 60 * 1000; // 30 menit
const HEARTBEAT_INTERVAL = 5000; // cek tiap 5 detik
const FREEZE_LIMIT = 20000; // jika 20 detik tidak update = freeze

let lastHeartbeat = Date.now();

function kirimStatusServer(pesan) {
  try {
    if (typeof sendToGroupsUtama === "function") {
      sendToGroupsUtama(
        `🟣 *Status Panel*\n${pesan}`,
        { parse_mode: "Markdown" }
      );
    }
  } catch (err) {
    console.log("Telegram send error:", err.message);
  }
}

kirimStatusServer("✅ Server aktif dan berjalan normal.");

setInterval(() => {
  lastHeartbeat = Date.now();
}, HEARTBEAT_INTERVAL);

setInterval(() => {

  const now = Date.now();

  if (now - lastHeartbeat > FREEZE_LIMIT) {

    console.log("⚠️ Server freeze terdeteksi!");

    kirimStatusServer(
      "⚠️ *Server terdeteksi freeze*\nPanel akan restart otomatis..."
    );

    setTimeout(() => {
      process.exit(1);
    }, 4000);

  }

}, 10000);

setInterval(() => {

  console.log("♻️ Restart berkala...");

  kirimStatusServer(
    "♻️ *Restart otomatis*\nPanel restart untuk menjaga kestabilan."
  );

  setTimeout(() => {
    process.exit(1);
  }, 5000);

}, RESTART_INTERVAL);

process.on("uncaughtException", (err) => {

  console.error("UNCAUGHT ERROR:", err);

  kirimStatusServer(
    "❌ *Server crash*\nPanel akan restart otomatis."
  );

  setTimeout(() => {
    process.exit(1);
  }, 4000);

});

process.on("unhandledRejection", (err) => {

  console.error("UNHANDLED PROMISE:", err);

  kirimStatusServer(
    "❌ *Unhandled Promise Error*\nPanel restart otomatis."
  );

  setTimeout(() => {
    process.exit(1);
  }, 4000);

});