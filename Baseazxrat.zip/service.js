const fs = require('fs');
const readline = require('readline');
const path = require('path');

const filePath = './database.json';
const SESSION_DIR = './aan'; // Sesuaikan dengan direktori session kamu

// Baca database
function loadDatabase() {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        console.log('❌ Gagal membaca database:', err.message);
        return [];
    }
}

// Simpan database
function saveDatabase(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}

// Hapus user berdasarkan role
function deleteByRole(role) {
    const db = loadDatabase();
    const toDelete = db.filter(user => user.role === role);
    const remaining = db.filter(user => user.role !== role);
    
    saveDatabase(remaining);
    
    console.log(`\n✅ Berhasil menghapus ${toDelete.length} user dengan role "${role}"`);
    console.log(`📊 Tersisa ${remaining.length} user di database`);
    
    if (toDelete.length > 0 && toDelete.length <= 20) {
        console.log(`\nUser yang dihapus:`);
        toDelete.forEach(user => console.log(`   - ${user.username} (${user.role})`));
    }
}

// Tampilkan statistik user database
function showStats() {
    const db = loadDatabase();
    const stats = {};
    db.forEach(user => {
        stats[user.role] = (stats[user.role] || 0) + 1;
    });
    
    console.log(`\n📊 STATISTIK USER DATABASE:`);
    console.log(`📁 Total: ${db.length} user`);
    console.log(`━━━━━━━━━━━━━━━━━━━━`);
    for (const [role, count] of Object.entries(stats)) {
        console.log(`   ${role}: ${count} user`);
    }
    console.log(`━━━━━━━━━━━━━━━━━━━━`);
}

// ===================== FUNGSI SESSION =====================
// Cek apakah nomor aktif (ada file .json dengan nama yang sama)
function isNumberActive(folderName, userDir) {
    try {
        const jsonPath = path.join(userDir, `${folderName}.json`);
        return fs.existsSync(jsonPath);
    } catch (err) {
        return false;
    }
}

// Cek apakah folder user memiliki session aktif
function hasActiveSessions(userDir) {
    try {
        if (!fs.existsSync(userDir)) return false;
        
        const folders = fs.readdirSync(userDir);
        for (const folder of folders) {
            const folderPath = path.join(userDir, folder);
            if (!fs.statSync(folderPath).isDirectory()) continue;
            
            // Cek apakah ada file .json dengan nama yang sama
            if (isNumberActive(folder, userDir)) {
                return true;
            }
        }
        return false;
    } catch (err) {
        return false;
    }
}

// Bersihkan session sender offline + hapus user folder jika kosong
function clearSenderOffline() {
    console.log('\n🔍 Mencari dan membersihkan session sender offline...');
    
    if (!fs.existsSync(SESSION_DIR)) {
        console.log('❌ Folder session tidak ditemukan!');
        return;
    }
    
    const users = fs.readdirSync(SESSION_DIR);
    let totalDeletedSessions = 0;
    let totalDeletedUsers = 0;
    let totalFolders = 0;
    let deletedSessions = [];
    let deletedUsers = [];
    
    for (const user of users) {
        const userDir = path.join(SESSION_DIR, user);
        
        // Cek apakah userDir adalah folder
        if (!fs.statSync(userDir).isDirectory()) continue;
        
        console.log(`\n📁 Memproses user: ${user}`);
        
        const folders = fs.readdirSync(userDir);
        let hasActive = false;
        let offlineSessions = [];
        
        // Cek semua session dalam user
        for (const folder of folders) {
            const folderPath = path.join(userDir, folder);
            
            // Cek apakah folderPath adalah folder
            if (!fs.statSync(folderPath).isDirectory()) continue;
            
            totalFolders++;
            
            // Cek apakah ada file json dengan nama yang sama
            const hasJson = isNumberActive(folder, userDir);
            
            if (hasJson) {
                hasActive = true;
                console.log(`   ✅  Aktif: ${folder}`);
            } else {
                offlineSessions.push(folder);
                console.log(`   ❌  Offline: ${folder}`);
            }
        }
        
        // Hapus session offline
        if (offlineSessions.length > 0) {
            for (const session of offlineSessions) {
                const sessionPath = path.join(userDir, session);
                try {
                    fs.rmSync(sessionPath, { recursive: true, force: true });
                    totalDeletedSessions++;
                    deletedSessions.push(`${user}/${session}`);
                    console.log(`   🗑️  Menghapus session: ${session}`);
                } catch (err) {
                    console.log(`   ❌ Gagal menghapus ${session}:`, err.message);
                }
            }
        }
        
        // Jika user tidak memiliki session aktif sama sekali, hapus folder user
        if (!hasActive && offlineSessions.length > 0) {
            try {
                fs.rmSync(userDir, { recursive: true, force: true });
                totalDeletedUsers++;
                deletedUsers.push(user);
                console.log(`   🗑️  Menghapus folder user: ${user} (semua session offline)`);
            } catch (err) {
                console.log(`   ❌ Gagal menghapus user ${user}:`, err.message);
            }
        } else if (!hasActive && offlineSessions.length === 0) {
            // Folder user kosong, hapus
            try {
                fs.rmSync(userDir, { recursive: true, force: true });
                totalDeletedUsers++;
                deletedUsers.push(user);
                console.log(`   🗑️  Menghapus folder user kosong: ${user}`);
            } catch (err) {
                console.log(`   ❌ Gagal menghapus user ${user}:`, err.message);
            }
        }
    }
    
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📊 HASIL PEMBERSIHAN:`);
    console.log(`📁 Total session dicek: ${totalFolders}`);
    console.log(`🗑️  Session offline dihapus: ${totalDeletedSessions}`);
    console.log(`🗑️  Folder user dihapus: ${totalDeletedUsers}`);
    console.log(`✅  Sisa session aktif: ${totalFolders - totalDeletedSessions}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    
    if (deletedSessions.length > 0 && deletedSessions.length <= 30) {
        console.log(`\n📋 Session yang dihapus:`);
        deletedSessions.forEach(s => console.log(`   - ${s}`));
    } else if (deletedSessions.length > 30) {
        console.log(`\n📋 ${deletedSessions.length} session berhasil dihapus (terlalu banyak untuk ditampilkan)`);
    }
    
    if (deletedUsers.length > 0 && deletedUsers.length <= 20) {
        console.log(`\n📋 Folder user yang dihapus:`);
        deletedUsers.forEach(u => console.log(`   - ${u}`));
    } else if (deletedUsers.length > 20) {
        console.log(`\n📋 ${deletedUsers.length} folder user berhasil dihapus (terlalu banyak untuk ditampilkan)`);
    }
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
}

// ===================== FUNGSI CLEANUP LANJUTAN =====================
// Hapus session yang sudah tua (lebih dari X hari)
function cleanOldSessions(days = 7) {
    console.log(`\n🧹 Membersihkan session lebih dari ${days} hari...`);
    
    if (!fs.existsSync(SESSION_DIR)) {
        console.log('❌ Folder session tidak ditemukan!');
        return;
    }
    
    const now = Date.now();
    const maxAge = days * 24 * 60 * 60 * 1000;
    let totalDeletedSessions = 0;
    let totalDeletedUsers = 0;
    let totalChecked = 0;
    
    const users = fs.readdirSync(SESSION_DIR);
    
    for (const user of users) {
        const userDir = path.join(SESSION_DIR, user);
        if (!fs.statSync(userDir).isDirectory()) continue;
        
        console.log(`\n📁 Memproses user: ${user}`);
        const folders = fs.readdirSync(userDir);
        let hasActive = false;
        let deletedOldSessions = [];
        
        for (const folder of folders) {
            const folderPath = path.join(userDir, folder);
            if (!fs.statSync(folderPath).isDirectory()) continue;
            
            totalChecked++;
            
            try {
                const stat = fs.statSync(folderPath);
                const age = now - stat.mtimeMs;
                
                // Cek apakah session aktif
                const isActive = isNumberActive(folder, userDir);
                
                // Hapus jika sudah tua dan tidak aktif
                if (age > maxAge && !isActive) {
                    fs.rmSync(folderPath, { recursive: true, force: true });
                    totalDeletedSessions++;
                    deletedOldSessions.push(folder);
                    console.log(`   🗑️  Menghapus session tua: ${folder} (${Math.floor(age/(24*60*60*1000))} hari)`);
                } else if (isActive) {
                    hasActive = true;
                    console.log(`   ✅  Session aktif: ${folder} (${Math.floor(age/(24*60*60*1000))} hari)`);
                } else {
                    console.log(`   ⏳  Session normal: ${folder} (${Math.floor(age/(24*60*60*1000))} hari)`);
                }
            } catch (err) {
                console.log(`   ❌ Error checking ${folder}:`, err.message);
            }
        }
        
        // Jika user tidak memiliki session aktif dan semua folder sudah dihapus
        if (!hasActive) {
            const remainingFolders = fs.readdirSync(userDir).filter(f => 
                fs.statSync(path.join(userDir, f)).isDirectory()
            );
            
            if (remainingFolders.length === 0) {
                try {
                    fs.rmSync(userDir, { recursive: true, force: true });
                    totalDeletedUsers++;
                    console.log(`   🗑️  Menghapus folder user: ${user} (kosong)`);
                } catch (err) {
                    console.log(`   ❌ Gagal menghapus user ${user}:`, err.message);
                }
            }
        }
    }
    
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📊 HASIL CLEANUP:`);
    console.log(`📁 Total session dicek: ${totalChecked}`);
    console.log(`🗑️  Session dihapus: ${totalDeletedSessions}`);
    console.log(`🗑️  Folder user dihapus: ${totalDeletedUsers}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
}

// Hitung total session aktif
function countActiveSessions() {
    if (!fs.existsSync(SESSION_DIR)) {
        console.log('❌ Folder session tidak ditemukan!');
        return 0;
    }
    
    let active = 0;
    let total = 0;
    let activeUsers = new Set();
    
    const users = fs.readdirSync(SESSION_DIR);
    
    console.log(`\n📊 STATISTIK SESSION:`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    
    for (const user of users) {
        const userDir = path.join(SESSION_DIR, user);
        if (!fs.statSync(userDir).isDirectory()) continue;
        
        const folders = fs.readdirSync(userDir);
        let userActive = 0;
        let userTotal = 0;
        
        for (const folder of folders) {
            const folderPath = path.join(userDir, folder);
            if (!fs.statSync(folderPath).isDirectory()) continue;
            
            userTotal++;
            total++;
            
            if (isNumberActive(folder, userDir)) {
                userActive++;
                active++;
                activeUsers.add(user);
            }
        }
        
        if (userTotal > 0) {
            console.log(`   ${user}: ${userActive}/${userTotal} aktif`);
        }
    }
    
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📁 Total folder: ${total}`);
    console.log(`✅  Session aktif: ${active}`);
    console.log(`❌  Session offline: ${total - active}`);
    console.log(`👤  User dengan session aktif: ${activeUsers.size}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    
    return active;
}

// ===================== FUNGSI RESET TOTAL =====================
// Hapus semua session (bersih total)
function resetAllSessions() {
    console.log('\n⚠️  PERINGATAN: Ini akan menghapus SEMUA session!');
    console.log('Ketik "YES" untuk konfirmasi:');
    
    const rlConfirm = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    rlConfirm.question('> ', (answer) => {
        if (answer.trim().toUpperCase() === 'YES') {
            try {
                if (fs.existsSync(SESSION_DIR)) {
                    fs.rmSync(SESSION_DIR, { recursive: true, force: true });
                    console.log('✅ Semua session berhasil dihapus!');
                } else {
                    console.log('❌ Folder session tidak ditemukan!');
                }
            } catch (err) {
                console.log('❌ Gagal menghapus session:', err.message);
            }
        } else {
            console.log('❌ Operasi dibatalkan.');
        }
        rlConfirm.close();
        rl.prompt();
    });
}

// ===================== CLI HANDLER =====================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function showHelp() {
    console.log(`
╔══════════════════════════════════════════════════════════════╗
║            USER & SESSION MANAGEMENT v3.0                   ║
╠══════════════════════════════════════════════════════════════╣
║  /delallvip          - Hapus semua VIP                     ║
║  /delallowner        - Hapus semua Owner                   ║
║  /delallres          - Hapus semua Reseller                ║
║  /delallmember       - Hapus semua Member                  ║
║  /clearsenderoff     - Hapus session offline + user kosong ║
║  /clearsession [days]- Hapus session > X hari (default 7)  ║
║  /stats              - Lihat statistik user database       ║
║  /sessionstats       - Lihat statistik session             ║
║  /resetallsessions   - Hapus SEMUA session (konfirmasi)    ║
║  /help               - Bantuan ini                         ║
║  /exit               - Keluar                              ║
╚══════════════════════════════════════════════════════════════╝
    `);
}

function processCommand(input) {
    const cmd = input.trim().toLowerCase();
    
    // Handle command dengan parameter
    if (cmd.startsWith('/clearsession')) {
        const parts = cmd.split(' ');
        const days = parseInt(parts[1]) || 7;
        if (days > 0) {
            cleanOldSessions(days);
        } else {
            console.log('❌ Masukkan jumlah hari yang valid!');
        }
        return true;
    }
    
    switch(cmd) {
        case '/delallvip':
            deleteByRole('vip');
            break;
        case '/delallowner':
            deleteByRole('owner');
            break;
        case '/delallres':
        case '/delallreseller':
            deleteByRole('reseller');
            break;
        case '/delallmember':
            deleteByRole('member');
            break;
        case '/clearsenderoff':
            clearSenderOffline();
            break;
        case '/sessionstats':
            countActiveSessions();
            break;
        case '/stats':
            showStats();
            break;
        case '/resetallsessions':
            resetAllSessions();
            return true; // Skip prompt karena ada konfirmasi
        case '/help':
            showHelp();
            break;
        case '/exit':
            console.log('👋 Goodbye!');
            rl.close();
            return false;
        default:
            if (cmd) console.log('❌ Command tidak dikenal. Ketik /help untuk bantuan.');
    }
    return true;
}

// ===================== AUTO CLEANUP =====================
// Jalankan auto cleanup setiap 1 jam
setInterval(() => {
    console.log('\n⏰ Auto cleanup session...');
    clearSenderOffline();
    console.log('✅ Auto cleanup selesai!');
    rl.prompt();
}, 60 * 60 * 1000); // 1 jam

// Jalankan pertama kali saat start
setTimeout(() => {
    console.log('\n🚀 Running initial cleanup...');
    clearSenderOffline();
    countActiveSessions();
    console.log('✅ Initial cleanup selesai!');
    rl.prompt();
}, 3000);

// ===================== START CLI =====================
console.log(`
╔══════════════════════════════════════════════════════════════╗
║   USER & SESSION MANAGEMENT v3.0                            ║
║   Database: ${filePath}
║   Session: ${SESSION_DIR}
║   Auto-cleanup: Setiap 1 jam
╚══════════════════════════════════════════════════════════════╝
`);
showStats();
countActiveSessions();
showHelp();

rl.setPrompt('> ');
rl.prompt();

rl.on('line', (line) => {
    const continueLoop = processCommand(line);
    if (continueLoop) {
        rl.prompt();
    }
});