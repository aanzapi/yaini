// ===== BOT STAFF MANAGEMENT + CREATE ACCOUNT =====
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// Config
const TOKEN = "8918920696:AAFevqpy1LdlZWIzF85EiDjRGqhig7zqKsE";
const STAFF_FILE = path.join(__dirname, "staff.json");
const DB_PATH = path.join(__dirname, "database.json");
const OWNER_ID = 8038424443;
const GROUP_ID = -1004352059364;
const NOTIF_GROUP = -1004352059364;

// Inisialisasi bot
const staffBot = new TelegramBot(TOKEN, { polling: true });

// ===== LINE DECORATION =====
const line = "━━━━━━━━━━━━━━";

// ===== DATABASE FUNCTIONS =====
function loadDatabase() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
  } catch (error) {
    console.error("[❌ DB] Error loading:", error.message);
    return [];
  }
}

function saveDatabase(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error("[❌ DB] Error saving:", error.message);
    return false;
  }
}

function generateRandomPassword(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

function isExpired(user) {
  return new Date(user.expiredDate) < new Date();
}

// ===== STAFF FUNCTIONS =====
function loadStaff() {
  try {
    if (!fs.existsSync(STAFF_FILE)) {
      const defaultData = {
        founder: [],
        owner: [],
        reseller: []
      };
      fs.writeFileSync(STAFF_FILE, JSON.stringify(defaultData, null, 2));
      return defaultData;
    }
    return JSON.parse(fs.readFileSync(STAFF_FILE, "utf8"));
  } catch (error) {
    console.error("[❌ STAFF] Error loading:", error.message);
    return { founder: [], owner: [], reseller: [] };
  }
}

function saveStaff(data) {
  try {
    fs.writeFileSync(STAFF_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error("[❌ STAFF] Error saving:", error.message);
    return false;
  }
}

function getUserRole(userId) {
  const data = loadStaff();
  if (data.founder.includes(userId)) return "founder";
  if (data.owner.includes(userId)) return "owner";
  if (data.reseller.includes(userId)) return "reseller";
  return null;
}

function isStaff(userId) {
  return getUserRole(userId) !== null;
}

function formatRole(role) {
  const map = {
    founder: "👑 Founder",
    owner: "⭐ Owner",
    reseller: "🛒 Reseller",
    vip: "💎 VIP",
    member: "👤 Member"
  };
  return map[role] || role;
}

function getAvailableCreateRoles(role) {
  // Owner utama bisa create semua role
  if (role === "owner_utama") {
    return ["founder", "owner", "reseller", "vip"];
  }
  
  switch (role) {
    case "founder":
      return ["owner", "reseller", "vip"];
    case "owner":
      return ["reseller", "vip"];
    case "reseller":
      return ["vip"];
    default:
      return [];
  }
}

function canCreateRole(userId, targetRole) {
  // Owner utama bisa create semua
  if (userId === OWNER_ID) return true;
  
  const role = getUserRole(userId);
  if (!role) return false;
  const available = getAvailableCreateRoles(role);
  return available.includes(targetRole);
}

function canDeleteRole(userId, targetRole) {
  // Owner utama bisa delete semua
  if (userId === OWNER_ID) return true;
  
  const role = getUserRole(userId);
  if (!role) return false;
  
  const canDelete = {
    founder: ["owner", "reseller", "vip", "member"],
    owner: ["reseller", "vip", "member"],
    reseller: ["vip", "member"]
  };
  
  return canDelete[role]?.includes(targetRole) || false;
}

function canEditRole(userId, targetRole) {
  // Owner utama bisa edit semua
  if (userId === OWNER_ID) return true;
  
  const role = getUserRole(userId);
  if (!role) return false;
  
  const canEdit = {
    founder: ["owner", "reseller", "vip", "member"],
    owner: ["reseller", "vip", "member"],
    reseller: ["vip", "member"]
  };
  
  return canEdit[role]?.includes(targetRole) || false;
}

// ===== SEND NOTIFICATION =====
async function sendNotifikasi(message) {
  try {
    await staffBot.sendMessage(NOTIF_GROUP, message, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("[❌ NOTIF] Gagal kirim:", error.message);
  }
}

// ===== CHECK GROUP =====
async function isUserInGroup(userId) {
  try {
    const member = await staffBot.getChatMember(GROUP_ID, userId);
    return member && (member.status === 'member' || member.status === 'administrator' || member.status === 'creator');
  } catch (error) {
    return false;
  }
}

// ===== AUTO REMOVE STAFF KELUAR GROUP =====
async function checkAllStaffInGroup() {
  console.log("[🔍 STAFF] Checking all staff in group...");
  const data = loadStaff();
  let removed = [];
  
  for (const role of ['founder', 'owner', 'reseller']) {
    for (const userId of data[role]) {
      const inGroup = await isUserInGroup(userId);
      if (!inGroup) {
        data[role] = data[role].filter(id => id !== userId);
        removed.push({ userId, role });
        console.log(`[🗑️ STAFF] Removed ${userId} (${role}) - not in group`);
        
        try {
          await staffBot.sendMessage(userId, 
            `⚠️ *Anda telah dihapus dari staff!*\n\n` +
            `Alasan: Keluar dari group wajib.\n` +
            `🏷️ *Role:* ${formatRole(role)}`,
            { parse_mode: "Markdown" }
          );
        } catch (error) {}
      }
    }
  }
  
  if (removed.length > 0) {
    saveStaff(data);
    let msg = `🗑️ *Staff Auto Removed*\n\n`;
    removed.forEach(r => {
      msg += `• \`${r.userId}\` - ${formatRole(r.role)}\n`;
    });
    msg += `\nAlasan: Keluar dari group wajib.`;
    
    try {
      await staffBot.sendMessage(OWNER_ID, msg, { parse_mode: "Markdown" });
    } catch (error) {}
  }
  
  return removed;
}

setInterval(async () => {
  await checkAllStaffInGroup();
}, 30 * 60 * 1000);

// ===== AUTO BACKUP STAFF.JSON =====
async function backupStaff() {
  try {
    if (!fs.existsSync(STAFF_FILE)) {
      console.log("[❌ BACKUP] staff.json not found");
      return;
    }
    
    const timestamp = new Date().toLocaleString('id-ID');
    await staffBot.sendDocument(OWNER_ID, STAFF_FILE, {
      caption: `📦 *BACKUP STAFF.JSON OTOMATIS*\n🕐 ${timestamp}`,
      parse_mode: 'Markdown'
    });
    
    console.log("[✅ BACKUP] Staff.json sent to owner");
  } catch (error) {
    console.error("[❌ BACKUP] Failed:", error.message);
  }
}

// Backup setiap 5 menit
setInterval(async () => {
  await backupStaff();
}, 5 * 60 * 1000);

// ===== COMMAND: START =====
staffBot.onText(/^\/start$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);
  const isOwner = userId === OWNER_ID;
  
  if (!role && !isOwner) {
    return staffBot.sendMessage(chatId, 
      "❌ Anda tidak memiliki akses ke bot ini.\n" +
      "Hubungi owner utama untuk mendapatkan akses."
    );
  }
  
  const inGroup = await isUserInGroup(userId);
  if (!inGroup && !isOwner) {
    const data = loadStaff();
    data[role] = data[role].filter(id => id !== userId);
    saveStaff(data);
    return staffBot.sendMessage(chatId, 
      "❌ Anda harus berada di group wajib untuk menggunakan bot ini."
    );
  }
  
  let availableRoles = [];
  if (isOwner) {
    availableRoles = ["founder", "owner", "reseller", "vip"];
  } else {
    availableRoles = getAvailableCreateRoles(role);
  }
  
  const keyboard = availableRoles.map(r => {
    const label = formatRole(r);
    return [{ text: `➕ ${label}`, callback_data: `create_${r}` }];
  });
  
  keyboard.push([
    { text: "📋 List Akun", callback_data: "list_accounts" },
    { text: "ℹ️ Info Saya", callback_data: "my_info" }
  ]);
  
  keyboard.push([
    { text: "⏳ Expired Soon", callback_data: "expired_soon" },
    { text: "📊 Statistik", callback_data: "stats" }
  ]);
  
  // Tambahan untuk owner utama
  if (isOwner) {
    keyboard.push([
      { text: "👑 Add Staff", callback_data: "add_staff_menu" },
      { text: "🗑️ Remove Staff", callback_data: "remove_staff_menu" }
    ]);
  }
  
  const roleText = isOwner ? "👑 Owner Utama" : formatRole(role);
  const menu = 
    `👋 *Selamat datang, ${msg.from.first_name}!*\n` +
    `${line}\n` +
    `🏷️ *Role Anda:* ${roleText}\n` +
    `📌 *Status:* ✅ Terdaftar di group\n` +
    `${line}\n` +
    `📋 *Yang bisa Anda lakukan:*\n` +
    `${availableRoles.map(r => `  ➜ ${formatRole(r)}`).join('\n')}\n` +
    `${line}\n` +
    `📌 *Pilih aksi di bawah ini:*`;
  
  await staffBot.sendPhoto(chatId, "https://cdn.phototourl.com/member/2026-07-17-9ee863d3-c729-4cfa-9ff3-d1cefe9b2be1.jpg", {
    caption: menu,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: keyboard
    }
  });
});

// ===== CALLBACK HANDLER =====
staffBot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const messageId = query.message.message_id;
  const username = query.from.username || query.from.first_name;
  const isOwner = userId === OWNER_ID;
  
  // ===== ADD STAFF (OWNER ONLY) =====
  if (data === "add_staff_menu") {
    if (!isOwner) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Hanya owner utama!",
        show_alert: true
      });
      return;
    }
    
    staffBot.deleteMessage(chatId, messageId);
    staffBot.sendMessage(chatId,
      `👑 *Tambah Staff Baru*\n${line}\n` +
      `Masukkan ID Telegram yang akan dijadikan staff:\n` +
      `\`/addstaff id_telegram\`\n\n` +
      `📌 *Contoh:*\n` +
      `\`/addstaff 123456789\`\n\n` +
      `Nanti akan muncul button pilih role.`,
      { parse_mode: "Markdown" }
    );
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  if (data === "remove_staff_menu") {
    if (!isOwner) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Hanya owner utama!",
        show_alert: true
      });
      return;
    }
    
    staffBot.deleteMessage(chatId, messageId);
    staffBot.sendMessage(chatId,
      `🗑️ *Hapus Staff*\n${line}\n` +
      `Masukkan ID Telegram staff yang akan dihapus:\n` +
      `\`/removestaff id_telegram\`\n\n` +
      `📌 *Contoh:*\n` +
      `\`/removestaff 123456789\``,
      { parse_mode: "Markdown" }
    );
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  // ===== ADD STAFF CALLBACK =====
  if (data.startsWith("addstaff_")) {
    const parts = data.split("_");
    const action = parts[1];
    const targetId = parseInt(parts[2]);
    
    if (!isOwner) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Hanya owner utama!",
        show_alert: true
      });
      return;
    }
    
    if (action === "cancel") {
      staffBot.deleteMessage(chatId, messageId);
      return staffBot.sendMessage(chatId, "❌ Dibatalkan.");
    }
    
    const targetRole = action;
    
    if (!['founder', 'owner', 'reseller'].includes(targetRole)) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Role tidak valid!",
        show_alert: true
      });
      return;
    }
    
    if (targetId === OWNER_ID) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Tidak bisa menambah owner utama!",
        show_alert: true
      });
      return;
    }
    
    if (isStaff(targetId)) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ ID sudah terdaftar!",
        show_alert: true
      });
      staffBot.deleteMessage(chatId, messageId);
      return staffBot.sendMessage(chatId, `❌ ID ${targetId} sudah terdaftar sebagai staff!`);
    }
    
    const inGroup = await isUserInGroup(targetId);
    if (!inGroup) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Target keluar dari group!",
        show_alert: true
      });
      staffBot.deleteMessage(chatId, messageId);
      return staffBot.sendMessage(chatId, `❌ Target sudah keluar dari group wajib!`);
    }
    
    const dataStaff = loadStaff();
    if (!dataStaff[targetRole]) dataStaff[targetRole] = [];
    dataStaff[targetRole].push(targetId);
    saveStaff(dataStaff);
    
    staffBot.deleteMessage(chatId, messageId);
    
    const resultMsg = 
      `✅ *Staff Berhasil Ditambahkan!*\n${line}\n` +
      `📌 *ID:* \`${targetId}\`\n` +
      `🏷️ *Role:* ${formatRole(targetRole)}\n` +
      `👨‍💼 *Ditambahkan Oleh:* Owner Utama\n` +
      `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`;
    
    await staffBot.sendMessage(chatId, resultMsg, { parse_mode: "Markdown" });
    
    try {
      await staffBot.sendMessage(targetId,
        `🎉 *Selamat! Anda telah ditambahkan sebagai staff!*\n${line}\n` +
        `🏷️ *Role:* ${formatRole(targetRole)}\n` +
        `👤 *Ditambahkan Oleh:* Owner Utama\n\n` +
        `📌 *Group Wajib:* Join untuk tetap aktif.\n` +
        `Gunakan /start untuk melihat menu.\n${line}`,
        { parse_mode: "Markdown" }
      );
    } catch (error) {}
    
    await sendNotifikasi(
      `👑 *STAFF BARU DITAMBAHKAN*\n${line}\n` +
      `📌 *ID:* \`${targetId}\`\n` +
      `🏷️ *Role:* ${formatRole(targetRole)}\n` +
      `👨‍💼 *Ditambahkan Oleh:* Owner Utama\n` +
      `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`
    );
    
    staffBot.answerCallbackQuery(query.id, {
      text: `✅ Berhasil tambah ${formatRole(targetRole)}!`
    });
    return;
  }
  
  // ===== REMOVE STAFF CALLBACK =====
  if (data.startsWith("removestaff_")) {
    const parts = data.split("_");
    const action = parts[1];
    const targetId = parseInt(parts[2]);
    
    if (!isOwner) {
      staffBot.answerCallbackQuery(query.id, {
        text: "❌ Hanya owner utama!",
        show_alert: true
      });
      return;
    }
    
    if (action === "cancel") {
      staffBot.deleteMessage(chatId, messageId);
      return staffBot.sendMessage(chatId, "❌ Dibatalkan.");
    }
    
    if (action === "yes") {
      if (targetId === OWNER_ID) {
        staffBot.answerCallbackQuery(query.id, {
          text: "❌ Tidak bisa hapus owner utama!",
          show_alert: true
        });
        return;
      }
      
      const role = getUserRole(targetId);
      if (!role) {
        staffBot.answerCallbackQuery(query.id, {
          text: "❌ Sudah bukan staff!",
          show_alert: true
        });
        staffBot.deleteMessage(chatId, messageId);
        return;
      }
      
      const dataStaff = loadStaff();
      dataStaff[role] = dataStaff[role].filter(id => id !== targetId);
      saveStaff(dataStaff);
      
      staffBot.deleteMessage(chatId, messageId);
      
      const resultMsg = 
        `✅ *Staff Berhasil Dihapus!*\n${line}\n` +
        `📌 *ID:* \`${targetId}\`\n` +
        `🏷️ *Role:* ${formatRole(role)}\n` +
        `👨‍💼 *Dihapus Oleh:* Owner Utama\n` +
        `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`;
      
      await staffBot.sendMessage(chatId, resultMsg, { parse_mode: "Markdown" });
      
      try {
        await staffBot.sendMessage(targetId,
          `⚠️ *Anda telah dihapus dari staff!*\n${line}\n` +
          `🏷️ *Role:* ${formatRole(role)}\n` +
          `👤 *Dihapus Oleh:* Owner Utama\n` +
          `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`,
          { parse_mode: "Markdown" }
        );
      } catch (error) {}
      
      await sendNotifikasi(
        `🗑️ *STAFF DIHAPUS*\n${line}\n` +
        `📌 *ID:* \`${targetId}\`\n` +
        `🏷️ *Role:* ${formatRole(role)}\n` +
        `👨‍💼 *Dihapus Oleh:* Owner Utama\n` +
        `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`
      );
      
      staffBot.answerCallbackQuery(query.id, {
        text: "✅ Staff berhasil dihapus!"
      });
    }
    return;
  }
  
  // ===== CHECK STAFF =====
  if (!isStaff(userId) && !isOwner) {
    staffBot.answerCallbackQuery(query.id, {
      text: "❌ Anda bukan staff!",
      show_alert: true
    });
    return;
  }
  
  const inGroup = await isUserInGroup(userId);
  if (!inGroup && !isOwner) {
    staffBot.answerCallbackQuery(query.id, {
      text: "❌ Anda harus di group wajib!",
      show_alert: true
    });
    return;
  }
  
  const role = getUserRole(userId);
  
  // ===== CREATE ACCOUNT =====
  if (data.startsWith("create_")) {
    const targetRole = data.replace("create_", "");
    
    if (!canCreateRole(userId, targetRole)) {
      staffBot.answerCallbackQuery(query.id, {
        text: `❌ Anda tidak bisa membuat ${formatRole(targetRole)}!`,
        show_alert: true
      });
      return;
    }
    
    staffBot.deleteMessage(chatId, messageId);
    
    staffBot.sendMessage(chatId, 
      `📝 *Buat Akun ${formatRole(targetRole)}*\n` +
      `${line}\n` +
      `Masukkan data dengan format:\n` +
      `\`username, hari\`\n\n` +
      `📌 *Contoh:*\n` +
      `\`ardi, 30\`\n` +
      `\`budi, 365\`\n\n` +
      `⏳ *Maksimal hari:* 365\n` +
      `🔐 *Password:* Auto generate\n\n` +
      `Ketik /batal untuk membatalkan.`,
      { parse_mode: "Markdown" }
    );
    
    const listener = async (msg) => {
      if (msg.text === '/batal' || msg.text === '/cancel') {
        staffBot.removeListener('message', listener);
        return staffBot.sendMessage(chatId, "❌ Pembuatan akun dibatalkan.");
      }
      
      const parts = msg.text.split(',').map(p => p.trim());
      
      if (parts.length < 2) {
        staffBot.sendMessage(chatId, 
          "❌ Format salah! Gunakan: `username, hari`\nContoh: `ardi, 30`",
          { parse_mode: "Markdown" }
        );
        return;
      }
      
      const username = parts[0];
      const days = parseInt(parts[1]);
      
      if (!username || username.length < 3) {
        staffBot.sendMessage(chatId, "❌ Username minimal 3 karakter.");
        return;
      }
      
      if (isNaN(days) || days <= 0 || days > 365) {
        staffBot.sendMessage(chatId, "❌ Hari harus antara 1-365.");
        return;
      }
      
      staffBot.removeListener('message', listener);
      
      const db = loadDatabase();
      
      if (db.find(u => u.username.toLowerCase() === username.toLowerCase())) {
        return staffBot.sendMessage(chatId, `❌ Username *${username}* sudah terdaftar!`, { parse_mode: "Markdown" });
      }
      
      const password = generateRandomPassword(8);
      const expired = new Date();
      expired.setDate(expired.getDate() + days);
      const expiredDate = expired.toISOString().split('T')[0];
      
      // Get creator name
      const creatorName = msg.from.first_name || msg.from.username || 'Unknown';
      
      db.push({
        username: username,
        password: password,
        role: targetRole,
        expiredDate: expiredDate,
        createdAt: new Date().toISOString(),
        createdBy: userId,
        createdByName: creatorName,
        createdVia: "Staff Bot"
      });
      
      saveDatabase(db);
      
      try {
        fs.appendFileSync('logUser.txt', `${creatorName} (${userId}) Created ${username} (${targetRole}) via Staff Bot at ${new Date().toLocaleString()}\n`);
      } catch (err) {}
      
      const resultMsg = 
        `✅ *Berhasil Buat Akun!*\n` +
        `${line}\n` +
        `👤 *Username:* ${username}\n` +
        `🔐 *Password:* \`${password}\`\n` +
        `🏷️ *Role:* ${formatRole(targetRole)}\n` +
        `📅 *Expired:* ${expiredDate} (${days} hari)\n` +
        `👨‍💼 *Dibuat Oleh:* ${creatorName}\n` +
        `${line}`;
      
      await staffBot.sendMessage(chatId, resultMsg, { parse_mode: "Markdown" });
      
      const fileContent = 
        `🎯 AKUN ${targetRole.toUpperCase()}\n` +
        `${line}\n` +
        `👤 Username: ${username}\n` +
        `🔐 Password: ${password}\n` +
        `🏷️ Role: ${targetRole}\n` +
        `📅 Expired: ${expiredDate}\n` +
        `📆 Durasi: ${days} hari\n` +
        `${line}\n` +
        `👨‍💼 Dibuat Oleh: ${creatorName}\n` +
        `🕐 Waktu: ${new Date().toLocaleString('id-ID')}`;
      
      const fileName = `${targetRole}_${username}_${Date.now()}.txt`;
      fs.writeFileSync(fileName, fileContent);
      await staffBot.sendDocument(chatId, fileName, {
        caption: `📁 Akun ${username} (${formatRole(targetRole)})`
      });
      fs.unlinkSync(fileName);
      
      const roleDisplay = isOwner ? "👑 Owner Utama" : formatRole(role);
      await sendNotifikasi(
        `📢 *AKUN BARU DIBUAT!*\n${line}\n` +
        `👤 *Username:* ${username}\n` +
        `🏷️ *Role:* ${formatRole(targetRole)}\n` +
        `📅 *Expired:* ${expiredDate} (${days} hari)\n` +
        `👨‍💼 *Dibuat Oleh:* ${creatorName} (${roleDisplay})\n` +
        `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n${line}`
      );
    };
    
    staffBot.on('message', listener);
    
    setTimeout(() => {
      staffBot.removeListener('message', listener);
    }, 60000);
    
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  // ===== LIST ACCOUNTS =====
  if (data === "list_accounts") {
    const db = loadDatabase();
    let filteredUsers = [];
    
    if (isOwner) {
      filteredUsers = db;
    } else {
      const staffRole = getUserRole(userId);
      switch (staffRole) {
        case "founder":
          filteredUsers = db;
          break;
        case "owner":
          filteredUsers = db.filter(u => ['reseller', 'vip', 'member'].includes(u.role));
          break;
        case "reseller":
          filteredUsers = db.filter(u => ['vip', 'member'].includes(u.role));
          break;
        default:
          filteredUsers = [];
      }
    }
    
    if (filteredUsers.length === 0) {
      return staffBot.sendMessage(chatId, "📭 Belum ada akun yang bisa dilihat.");
    }
    
    let message = `📋 *DAFTAR AKUN (${filteredUsers.length})*\n${line}\n`;
    const show = filteredUsers.slice(0, 20);
    show.forEach((u, i) => {
      const status = isExpired(u) ? "⛔" : "✅";
      message += `${i+1}. ${status} *${u.username}*\n`;
      message += `   🏷️ ${formatRole(u.role)} | 📆 ${u.expiredDate}\n`;
    });
    
    if (filteredUsers.length > 20) {
      message += `\n${line}\n📌 *Total:* ${filteredUsers.length} akun`;
    }
    
    staffBot.sendMessage(chatId, message, { parse_mode: "Markdown" });
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  // ===== MY INFO =====
  if (data === "my_info") {
    const staffRole = isOwner ? "👑 Owner Utama" : formatRole(getUserRole(userId));
    const db = loadDatabase();
    const myAccounts = db.filter(u => u.createdBy === userId);
    
    const info = 
      `👤 *Info Staff*\n` +
      `${line}\n` +
      `📌 *ID:* \`${userId}\`\n` +
      `👤 *Username:* @${username || 'Tidak ada'}\n` +
      `📛 *Nama:* ${query.from.first_name}\n` +
      `🏷️ *Role:* ${staffRole}\n` +
      `📊 *Total Akun Dibuat:* ${myAccounts.length}\n` +
      `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n` +
      `${line}`;
    
    staffBot.sendMessage(chatId, info, { parse_mode: "Markdown" });
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  // ===== EXPIRED SOON =====
  if (data === "expired_soon") {
    const db = loadDatabase();
    const now = new Date();
    const sevenDays = new Date();
    sevenDays.setDate(sevenDays.getDate() + 7);
    
    let filtered = db.filter(u => {
      const exp = new Date(u.expiredDate);
      return exp >= now && exp <= sevenDays;
    });
    
    if (!isOwner) {
      const staffRole = getUserRole(userId);
      const roleFilter = {
        founder: () => true,
        owner: (u) => ['reseller', 'vip', 'member'].includes(u.role),
        reseller: (u) => ['vip', 'member'].includes(u.role)
      };
      filtered = filtered.filter(roleFilter[staffRole] || (() => false));
    }
    
    if (filtered.length === 0) {
      return staffBot.sendMessage(chatId, "✅ Tidak ada akun yang akan expired dalam 7 hari.");
    }
    
    let message = `⏳ *AKAN EXPIRED (${filtered.length})*\n${line}\n`;
    filtered.sort((a, b) => new Date(a.expiredDate) - new Date(b.expiredDate));
    filtered.forEach((u, i) => {
      const daysLeft = Math.ceil((new Date(u.expiredDate) - new Date()) / (1000 * 60 * 60 * 24));
      message += `${i+1}. *${u.username}* - ${formatRole(u.role)}\n`;
      message += `   📅 ${u.expiredDate} (${daysLeft} hari lagi)\n`;
    });
    message += `${line}`;
    
    staffBot.sendMessage(chatId, message, { parse_mode: "Markdown" });
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  // ===== STATISTIK =====
  if (data === "stats") {
    const db = loadDatabase();
    
    const total = db.length;
    const active = db.filter(u => !isExpired(u)).length;
    const expired = db.filter(u => isExpired(u)).length;
    
    const roles = {};
    db.forEach(u => {
      roles[u.role] = (roles[u.role] || 0) + 1;
    });
    
    let roleStats = '';
    for (const [r, count] of Object.entries(roles)) {
      roleStats += `  ${formatRole(r)}: ${count}\n`;
    }
    
    const stats = 
      `📊 *STATISTIK AKUN*\n${line}\n` +
      `📌 *Total Akun:* ${total}\n` +
      `✅ *Aktif:* ${active}\n` +
      `⛔ *Expired:* ${expired}\n` +
      `${line}\n` +
      `📋 *Per Role:*\n${roleStats}${line}`;
    
    staffBot.sendMessage(chatId, stats, { parse_mode: "Markdown" });
    staffBot.answerCallbackQuery(query.id);
    return;
  }
  
  staffBot.answerCallbackQuery(query.id);
});

// ===== COMMAND: ADD STAFF (OWNER ONLY) =====
staffBot.onText(/^\/addstaff\s+(\d+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const targetId = parseInt(match[1]);
  
  if (userId !== OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Hanya owner utama yang bisa menambah staff!");
  }
  
  if (targetId === OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Tidak bisa menambahkan diri sendiri!");
  }
  
  if (isStaff(targetId)) {
    return staffBot.sendMessage(chatId, `❌ ID ${targetId} sudah terdaftar sebagai staff!`);
  }
  
  const inGroup = await isUserInGroup(targetId);
  if (!inGroup) {
    return staffBot.sendMessage(chatId, 
      `❌ Target tidak berada di group wajib!\n` +
      `Minta target join dulu.`
    );
  }
  
  let targetName = "Unknown";
  try {
    const member = await staffBot.getChatMember(GROUP_ID, targetId);
    targetName = member.user.first_name || member.user.username || "Unknown";
  } catch (error) {}
  
  const keyboard = [
    [{ text: "👑 Founder", callback_data: `addstaff_founder_${targetId}` }],
    [{ text: "⭐ Owner", callback_data: `addstaff_owner_${targetId}` }],
    [{ text: "🛒 Reseller", callback_data: `addstaff_reseller_${targetId}` }],
    [{ text: "❌ Batal", callback_data: "addstaff_cancel" }]
  ];
  
  staffBot.sendMessage(chatId,
    `👑 *Tambah Staff Baru*\n${line}\n` +
    `📌 *ID:* \`${targetId}\`\n` +
    `👤 *Nama:* ${targetName}\n` +
    `✅ *Status:* Sudah di group wajib\n` +
    `${line}\n` +
    `📌 *Pilih Role untuk staff ini:*`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: keyboard
      }
    }
  );
});

// ===== COMMAND: REMOVE STAFF (OWNER ONLY) =====
staffBot.onText(/^\/removestaff\s+(\d+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const targetId = parseInt(match[1]);
  
  if (userId !== OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Hanya owner utama yang bisa menghapus staff!");
  }
  
  if (targetId === OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Tidak bisa menghapus diri sendiri!");
  }
  
  const role = getUserRole(targetId);
  if (!role) {
    return staffBot.sendMessage(chatId, `❌ ID ${targetId} bukan staff!`);
  }
  
  let targetName = "Unknown";
  try {
    const member = await staffBot.getChatMember(GROUP_ID, targetId);
    targetName = member.user.first_name || member.user.username || "Unknown";
  } catch (error) {}
  
  const keyboard = [
    [
      { text: "✅ Ya, Hapus", callback_data: `removestaff_yes_${targetId}` },
      { text: "❌ Batal", callback_data: "removestaff_cancel" }
    ]
  ];
  
  staffBot.sendMessage(chatId,
    `⚠️ *Konfirmasi Hapus Staff*\n${line}\n` +
    `📌 *ID:* \`${targetId}\`\n` +
    `👤 *Nama:* ${targetName}\n` +
    `🏷️ *Role:* ${formatRole(role)}\n` +
    `${line}\n` +
    `Yakin ingin menghapus staff ini?`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: keyboard
      }
    }
  );
});

// ===== COMMAND: CREATE (TEXT) =====
staffBot.onText(/^\/create$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  let availableRoles = [];
  if (isOwner) {
    availableRoles = ["founder", "owner", "reseller", "vip"];
  } else {
    availableRoles = getAvailableCreateRoles(role);
  }
  
  const keyboard = availableRoles.map(r => {
    const label = formatRole(r);
    return [{ text: `➕ ${label}`, callback_data: `create_${r}` }];
  });
  
  keyboard.push([{ text: "❌ Batal", callback_data: "add_cancel" }]);
  
  staffBot.sendMessage(chatId,
    `📝 *Pilih Role Yang Ingin Dibuat*\n${line}\n` +
    `Role yang bisa Anda buat:\n${availableRoles.map(r => `  ➜ ${formatRole(r)}`).join('\n')}\n${line}`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: keyboard
      }
    }
  );
});

// ===== COMMAND: EDIT/PERPANJANG AKUN =====
staffBot.onText(/^\/edit$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  staffBot.sendMessage(chatId,
    `✏️ *Perpanjang Akun*\n${line}\n` +
    `Masukkan data dengan format:\n` +
    `\`username, tambah_hari\`\n\n` +
    `📌 *Contoh:*\n` +
    `\`ardi, 30\` (tambah 30 hari)\n\n` +
    `Ketik /batal untuk membatalkan.`,
    { parse_mode: "Markdown" }
  );
  
  const listener = async (msg) => {
    if (msg.text === '/batal') {
      staffBot.removeListener('message', listener);
      return staffBot.sendMessage(chatId, "❌ Dibatalkan.");
    }
    
    const parts = msg.text.split(',').map(p => p.trim());
    if (parts.length < 2) {
      staffBot.sendMessage(chatId, "❌ Format salah! Gunakan: `username, hari`", { parse_mode: "Markdown" });
      return;
    }
    
    const username = parts[0];
    const addDays = parseInt(parts[1]);
    
    if (isNaN(addDays) || addDays <= 0 || addDays > 365) {
      staffBot.sendMessage(chatId, "❌ Hari harus antara 1-365.");
      return;
    }
    
    staffBot.removeListener('message', listener);
    
    const db = loadDatabase();
    const user = db.find(u => u.username.toLowerCase() === username.toLowerCase());
    
    if (!user) {
      return staffBot.sendMessage(chatId, `❌ Username *${username}* tidak ditemukan!`, { parse_mode: "Markdown" });
    }
    
    if (!canEditRole(userId, user.role)) {
      return staffBot.sendMessage(chatId, 
        `❌ Anda tidak bisa memperpanjang ${formatRole(user.role)}!`, 
        { parse_mode: "Markdown" }
      );
    }
    
    const oldDate = user.expiredDate;
    const current = new Date(user.expiredDate);
    current.setDate(current.getDate() + addDays);
    user.expiredDate = current.toISOString().split('T')[0];
    
    saveDatabase(db);
    
    const creatorName = msg.from.first_name || msg.from.username || 'Unknown';
    const roleDisplay = isOwner ? "👑 Owner Utama" : formatRole(role);
    
    const resultMsg = 
      `✅ *Akun Diperpanjang!*\n${line}\n` +
      `👤 *Username:* ${username}\n` +
      `📅 *Expired Lama:* ${oldDate}\n` +
      `📅 *Expired Baru:* ${user.expiredDate}\n` +
      `📆 *Tambah:* ${addDays} hari\n` +
      `👨‍💼 *Diubah Oleh:* ${creatorName}\n${line}`;
    
    await staffBot.sendMessage(chatId, resultMsg, { parse_mode: "Markdown" });
    
    await sendNotifikasi(
      `✏️ *AKUN DIPERPANJANG*\n${line}\n` +
      `👤 *Username:* ${username}\n` +
      `📅 *Expired Baru:* ${user.expiredDate}\n` +
      `📆 *Tambah:* ${addDays} hari\n` +
      `👨‍💼 *Diubah Oleh:* ${creatorName} (${roleDisplay})\n${line}`
    );
  };
  
  staffBot.on('message', listener);
  setTimeout(() => staffBot.removeListener('message', listener), 60000);
});

// ===== COMMAND: DELETE AKUN =====
staffBot.onText(/^\/delete$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  staffBot.sendMessage(chatId,
    `🗑️ *Hapus Akun*\n${line}\n` +
    `Masukkan username yang akan dihapus:\n` +
    `\`username\`\n\n` +
    `📌 *Contoh:* \`ardi\`\n\n` +
    `⚠️ *Perhatian:* Hanya bisa menghapus akun dengan role dibawah Anda.\n` +
    `Ketik /batal untuk membatalkan.`,
    { parse_mode: "Markdown" }
  );
  
  const listener = async (msg) => {
    if (msg.text === '/batal') {
      staffBot.removeListener('message', listener);
      return staffBot.sendMessage(chatId, "❌ Dibatalkan.");
    }
    
    const username = msg.text.trim();
    staffBot.removeListener('message', listener);
    
    const db = loadDatabase();
    const userIndex = db.findIndex(u => u.username.toLowerCase() === username.toLowerCase());
    
    if (userIndex === -1) {
      return staffBot.sendMessage(chatId, `❌ Username *${username}* tidak ditemukan!`, { parse_mode: "Markdown" });
    }
    
    const user = db[userIndex];
    const userRole = user.role;
    
    if (!canDeleteRole(userId, userRole)) {
      return staffBot.sendMessage(chatId, 
        `❌ Anda tidak bisa menghapus ${formatRole(userRole)}!`, 
        { parse_mode: "Markdown" }
      );
    }
    
    db.splice(userIndex, 1);
    saveDatabase(db);
    
    const creatorName = msg.from.first_name || msg.from.username || 'Unknown';
    const roleDisplay = isOwner ? "👑 Owner Utama" : formatRole(role);
    
    const resultMsg = 
      `✅ *Akun Dihapus!*\n${line}\n` +
      `👤 *Username:* ${username}\n` +
      `🏷️ *Role:* ${formatRole(userRole)}\n` +
      `📅 *Expired:* ${user.expiredDate}\n` +
      `👨‍💼 *Dihapus Oleh:* ${creatorName}\n${line}`;
    
    await staffBot.sendMessage(chatId, resultMsg, { parse_mode: "Markdown" });
    
    await sendNotifikasi(
      `🗑️ *AKUN DIHAPUS*\n${line}\n` +
      `👤 *Username:* ${username}\n` +
      `🏷️ *Role:* ${formatRole(userRole)}\n` +
      `👨‍💼 *Dihapus Oleh:* ${creatorName} (${roleDisplay})\n${line}`
    );
  };
  
  staffBot.on('message', listener);
  setTimeout(() => staffBot.removeListener('message', listener), 60000);
});

// ===== COMMAND: INFO AKUN =====
staffBot.onText(/^\/info (\S+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  const username = match[1];
  const db = loadDatabase();
  const user = db.find(u => u.username.toLowerCase() === username.toLowerCase());
  
  if (!user) {
    return staffBot.sendMessage(chatId, `❌ Username *${username}* tidak ditemukan!`, { parse_mode: "Markdown" });
  }
  
  const info = 
    `🔍 *Info Akun*\n${line}\n` +
    `👤 *Username:* ${user.username}\n` +
    `🏷️ *Role:* ${formatRole(user.role)}\n` +
    `📅 *Expired:* ${user.expiredDate}\n` +
    `📊 *Status:* ${isExpired(user) ? '⛔ Expired' : '✅ Aktif'}\n` +
    `👨‍💼 *Dibuat Oleh:* ${user.createdByName || 'Unknown'}\n` +
    `🕐 *Dibuat:* ${user.createdAt || 'Unknown'}\n${line}`;
  
  staffBot.sendMessage(chatId, info, { parse_mode: "Markdown" });
});

// ===== COMMAND: EXPIRED SOON =====
staffBot.onText(/^\/expired$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  const db = loadDatabase();
  const now = new Date();
  const sevenDays = new Date();
  sevenDays.setDate(sevenDays.getDate() + 7);
  
  let filtered = db.filter(u => {
    const exp = new Date(u.expiredDate);
    return exp >= now && exp <= sevenDays;
  });
  
  if (!isOwner) {
    const staffRole = getUserRole(userId);
    const roleFilter = {
      founder: () => true,
      owner: (u) => ['reseller', 'vip', 'member'].includes(u.role),
      reseller: (u) => ['vip', 'member'].includes(u.role)
    };
    filtered = filtered.filter(roleFilter[staffRole] || (() => false));
  }
  
  if (filtered.length === 0) {
    return staffBot.sendMessage(chatId, "✅ Tidak ada akun yang akan expired dalam 7 hari.");
  }
  
  let message = `⏳ *AKAN EXPIRED (${filtered.length})*\n${line}\n`;
  filtered.sort((a, b) => new Date(a.expiredDate) - new Date(b.expiredDate));
  filtered.forEach((u, i) => {
    const daysLeft = Math.ceil((new Date(u.expiredDate) - new Date()) / (1000 * 60 * 60 * 24));
    message += `${i+1}. *${u.username}* - ${formatRole(u.role)}\n`;
    message += `   📅 ${u.expiredDate} (${daysLeft} hari lagi)\n`;
  });
  message += `${line}`;
  
  staffBot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

// ===== COMMAND: STATISTIK =====
staffBot.onText(/^\/stats$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  
  const db = loadDatabase();
  
  const total = db.length;
  const active = db.filter(u => !isExpired(u)).length;
  const expired = db.filter(u => isExpired(u)).length;
  
  const roles = {};
  db.forEach(u => {
    roles[u.role] = (roles[u.role] || 0) + 1;
  });
  
  let roleStats = '';
  for (const [r, count] of Object.entries(roles)) {
    roleStats += `  ${formatRole(r)}: ${count}\n`;
  }
  
  const stats = 
    `📊 *STATISTIK AKUN*\n${line}\n` +
    `📌 *Total Akun:* ${total}\n` +
    `✅ *Aktif:* ${active}\n` +
    `⛔ *Expired:* ${expired}\n` +
    `${line}\n` +
    `📋 *Per Role:*\n${roleStats}${line}`;
  
  staffBot.sendMessage(chatId, stats, { parse_mode: "Markdown" });
});

// ===== COMMAND: LIST STAFF =====
staffBot.onText(/^\/list$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  
  if (!isStaff(userId) && !isOwner) {
    return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  }
  
  const inGroup = await isUserInGroup(userId);
  if (!inGroup && !isOwner) {
    return staffBot.sendMessage(chatId, "❌ Anda harus berada di group wajib!");
  }
  
  const data = loadStaff();
  let message = `📋 *DAFTAR STAFF*\n${line}\n`;
  
  for (const role of ['founder', 'owner', 'reseller']) {
    if (data[role].length > 0) {
      const icon = role === 'founder' ? '👑' : role === 'owner' ? '⭐' : '🛒';
      message += `${icon} *${formatRole(role)} (${data[role].length})*\n`;
      for (const id of data[role]) {
        try {
          const member = await staffBot.getChatMember(GROUP_ID, id);
          const user = member.user;
          message += `  • ${user.first_name} (@${user.username || 'tidak ada'}) - \`${id}\`\n`;
        } catch {
          message += `  • \`${id}\`\n`;
        }
      }
      message += `\n`;
    }
  }
  
  const total = data.founder.length + data.owner.length + data.reseller.length;
  message += `${line}\n📊 *Total Staff:* ${total}`;
  
  staffBot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

// ===== COMMAND: BROADCAST =====
staffBot.onText(/^\/broadcast (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (userId !== OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Hanya owner utama yang bisa broadcast!");
  }
  
  const message = match[1];
  const data = loadStaff();
  const allStaff = [...data.founder, ...data.owner, ...data.reseller];
  
  if (allStaff.length === 0) {
    return staffBot.sendMessage(chatId, "❌ Tidak ada staff untuk di-broadcast.");
  }
  
  await staffBot.sendMessage(chatId, `⏳ Mengirim broadcast ke ${allStaff.length} staff...`);
  
  let sent = 0;
  for (const id of allStaff) {
    try {
      await staffBot.sendMessage(id, 
        `📢 *BROADCAST DARI OWNER*\n${line}\n${message}\n${line}`,
        { parse_mode: "Markdown" }
      );
      sent++;
      await new Promise(r => setTimeout(r, 100));
    } catch (error) {
      console.log(`[❌ BROADCAST] Gagal kirim ke ${id}:`, error.message);
    }
  }
  
  staffBot.sendMessage(chatId, 
    `✅ *Broadcast Terkirim!*\n${line}\n` +
    `📤 *Terkirim ke:* ${sent} staff\n` +
    `📌 *Total Staff:* ${allStaff.length}\n${line}`,
    { parse_mode: "Markdown" }
  );
});

// ===== COMMAND: BACKUP MANUAL =====
staffBot.onText(/^\/backup$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (userId !== OWNER_ID) {
    return staffBot.sendMessage(chatId, "❌ Hanya owner utama yang bisa backup!");
  }
  
  await staffBot.sendMessage(chatId, "📦 Membuat backup staff.json...");
  await backupStaff();
  await staffBot.sendMessage(chatId, "✅ Backup staff.json berhasil dikirim!");
});

// ===== COMMAND: HELP =====
staffBot.onText(/^\/help$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = userId === OWNER_ID;
  const role = getUserRole(userId);
  
  if (!role && !isOwner) {
    return staffBot.sendMessage(chatId, "❌ Anda bukan staff!");
  }
  
  let help = 
    `📖 *Bantuan Staff Bot*\n${line}\n` +
    `/start - Menu utama\n` +
    `/create - Buat akun baru\n` +
    `/edit - Perpanjang akun\n` +
    `/delete - Hapus akun\n` +
    `/info username - Cek detail akun\n` +
    `/expired - Lihat akun akan expired\n` +
    `/stats - Statistik akun\n` +
    `/list - Lihat semua staff\n` +
    `/help - Bantuan ini\n`;
  
  if (isOwner) {
    help += 
      `${line}\n` +
      `👑 *COMMAND OWNER UTAMA:*\n` +
      `/addstaff [id] - Tambah staff (pilih role via button)\n` +
      `/removestaff [id] - Hapus staff\n` +
      `/broadcast pesan - Broadcast ke semua staff\n` +
      `/backup - Backup staff.json manual\n` +
      `📌 *Bisa membuat:* Founder, Owner, Reseller, VIP\n`;
  } else {
    help += 
      `${line}\n` +
      `📌 *Role Anda:* ${formatRole(role)}\n` +
      `📌 *Bisa membuat:* ${getAvailableCreateRoles(role).map(r => formatRole(r)).join(', ')}\n`;
  }
  
  help += 
    `${line}\n` +
    `📝 *Format Create:*\n` +
    `\`username, hari\`\n` +
    `Contoh: \`ardi, 30\``;
  
  staffBot.sendMessage(chatId, help, { parse_mode: "Markdown" });
});

// ===== STARTUP CHECK =====
setTimeout(async () => {
  console.log("[🔍 STAFF] Initial group check...");
  await checkAllStaffInGroup();
}, 5000);

// Error handling
staffBot.on("polling_error", (err) => {
  console.log("[❌ STAFF BOT] Polling error:", err.message);
});

console.log("✅ Staff Bot started!");
console.log(`${line}`);
console.log(`📌 Founder: ${loadStaff().founder.length}`);
console.log(`📌 Owner: ${loadStaff().owner.length}`);
console.log(`📌 Reseller: ${loadStaff().reseller.length}`);
console.log(`${line}`);

// Export untuk index.js
module.exports = { staffBot, loadStaff, saveStaff, getUserRole, isStaff, checkAllStaffInGroup };